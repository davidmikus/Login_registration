from flask_app import app
from flask_app.models.user import User
from flask import render_template, redirect, session, request, flash
from flask_app.models.recipe import Recipe


@app.route("/recipes/board")
def recipes_home():
    if "user_id" not in session:
        flash("you must be loged in ")
        return redirect("/")
    user = User.get_by_id(session["user_id"])
    recipes = Recipe.get_all(session['user_id'])
    return render_template("board.html", user=user, recipes=recipes)


@app.route('/recipes/<int:recipe_id>', methods=['GET'])
def recipe_details(recipe_id):
    recipe = Recipe.get_one_by_id(recipe_id)
    return render_template('recipe_detail.html', recipe=recipe)


@app.route('/recipes', methods=['GET'])
def create_page():
    return render_template('create_recipe.html')


@app.route('/recipes/edit/<int:recipe_id>', methods=['GET'])
def edit_page(recipe_id):
    if Recipe.check_permissions(recipe_id):
        recipe = Recipe.get_one_by_id(recipe_id)
        return render_template('edit_recipe.html', recipe=recipe)
    return redirect("/recipes/board")


@app.route('/recipes/delete/<int:recipe_id>')
def delete_recipe(recipe_id):
    Recipe.delete_by_id(recipe_id)
    return redirect('/recipes/board')


@app.route('/recipes', methods=['POST'])
def create_recipe():
    is_valid = Recipe.is_valid(request.form)
    if is_valid:
        Recipe.save(request.form)
        return redirect('/recipes/board')
    return redirect('/recipes')


@app.route('/recipes/edit/<int:recipe_id>', methods=['POST'])
def update_recipe(recipe_id):
    if Recipe.check_permissions(recipe_id):
        is_valid = Recipe.is_valid(request.form)
        req = {**request.form, "id": recipe_id}
        if is_valid:
            Recipe.update_recipe(req)
            return redirect('/recipes/board')
        return redirect(f"/recipes/edit/{recipe_id}")
    return redirect("/recipes/board")
