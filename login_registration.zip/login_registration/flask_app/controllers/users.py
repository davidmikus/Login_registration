from flask import render_template, redirect, session, request, flash
from flask_app import app
from flask_app.models.user import User
from flask_app.config.mysqlconnection import connectToMySQL


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['POST', 'GET'])
def register():
    if not request.method == 'POST':
        return render_template('index.html')

    if not User.validate_register(request.form):
        return redirect('/')
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "password": request.form['password']
    }
    id = User.save(data)
    session['user_id'] = id

    return redirect('/recipes/board')


@app.route('/login', methods=['POST'])
def login():
    user = User.get_by_email(request.form)

    if not user:
        flash("Invalid Email", "login")
        return redirect('/')
    session['user_id'] = user.id
    return redirect('/recipes/board')


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
