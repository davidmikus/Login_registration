from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash, session
from flask_app.models import user
from datetime import datetime
import re


class Recipe:
    DB = "login_registration"

    def __init__(self, recipe):
        self.id = recipe["id"]
        self.name = recipe["name"]
        self.description = recipe["description"]
        self.instruction = recipe["instruction"]
        self.date_made = recipe["date_made"]
        self.under_30 = recipe["under_30"]
        self.created_at = recipe["created_at"]
        self.updated_at = recipe["updated_at"]
        self.user = None

    @classmethod
    def check_permissions(cls, recipe_id):
        data = {"id": recipe_id}
        query = """SELECT user_id FROM recipes WHERE id = %(id)s"""
        response = connectToMySQL(cls.DB).query_db(query, data)[0]
        if int(response["user_id"]) == int(session['user_id']):
            return True
        return False





    @classmethod
    def get_one_by_id(cls, recipe_id):
        query = """ SELECT recipes.*, users.*
                    FROM recipes
                    JOIN users ON recipes.user_id = users.id WHERE recipes.id = %(id)s;"""
        data = {"id": recipe_id}
        recipe_dict = connectToMySQL(cls.DB).query_db(query, data)[0]
        recipe_obj = Recipe(recipe_dict)
        user_obj = user.User(
            {
                "id": recipe_dict["users.id"],
                "first_name": recipe_dict["first_name"],
                "last_name": recipe_dict["last_name"],
                "email": recipe_dict["email"],
                "password": recipe_dict["password"],
                "created_at": recipe_dict["users.created_at"],
                "updated_at": recipe_dict["users.updated_at"],
            }
        )
        recipe_obj.user = user_obj
        return recipe_obj

    @classmethod
    def save(cls, recipe_data):
        recipe_data = {**recipe_data}
        created = datetime.now()
        recipe_data['created_at'] = created
        recipe_data['updated_at'] = created
        recipe_data['user_id'] = session['user_id']
        recipe_data["under_30"] = bool(recipe_data.get("under_30"))
        query = """INSERT INTO recipes(name, description, instruction, date_made, under_30, created_at, updated_at, user_id ) 
        VALUES (%(name)s, %(description)s, %(instruction)s, %(date_made)s, %(under_30)s, %(created_at)s, %(updated_at)s, %(user_id)s);"""

        connectToMySQL(cls.DB).query_db(query, recipe_data)

    @classmethod
    def get_all(cls, user_id):
        query = """SELECT recipes.*, users.*
                    FROM recipes
                    JOIN users ON recipes.user_id = users.id
                    """
        results = connectToMySQL(cls.DB).query_db(query)
        recipes = []

        for recipe_dict in results:
            recipe_obj = Recipe(recipe_dict)
            user_obj = user.User(
                {
                    "id": recipe_dict["users.id"],
                    "first_name": recipe_dict["first_name"],
                    "last_name": recipe_dict["last_name"],
                    "email": recipe_dict["email"],
                    "password": recipe_dict["password"],
                    "created_at": recipe_dict["users.created_at"],
                    "updated_at": recipe_dict["users.updated_at"],
                }
            )

            recipe_obj.user = user_obj
            recipes.append(recipe_obj)
        return recipes
    @classmethod
    def delete_by_id(cls, recipe_id):
        query = """DELETE FROM recipes WHERE id =%(id)s"""
        data = {"id": recipe_id}
        connectToMySQL(cls.DB).query_db(query, data)
        return

    @classmethod
    def is_valid(cls, recipe_dict):
        valid = True

        if len(recipe_dict.get("name", "recipes")) == 0:
            valid = False
            flash("you need a name")
        if len(recipe_dict.get("description", "recipes")) == 0:
            valid = False
            flash("you need description")
        elif len(recipe_dict.get("description", "recipes")) < 3:
            valid = False
            flash(" description needs to be at least 3 characters", "recipes")
        if len(recipe_dict.get("instruction")) == 0:
            valid = False
            flash("you need instruction")
        elif len(recipe_dict.get("instruction", "recipes")) < 3:
            valid = False
            flash(" instruction needs to be at least 3 characters", "recipes")

        if len(recipe_dict.get("date_made")) == 0:
            valid = False
            flash("date required")
        return valid

    @classmethod
    def update_recipe(cls, recipe_data):
        updated_at = datetime.now()
        recipe_data['updated_at'] = updated_at
        recipe_data['under_30'] = bool(recipe_data.get('under_30'))
        query = """UPDATE recipes SET 
                    name = %(name)s, 
                    description = %(description)s, 
                    updated_at = %(updated_at)s, 
                    instruction = %(instruction)s, 
                    date_made = %(date_made)s, 
                    under_30 = %(under_30)s 
                    WHERE id = %(id)s;"""
        connectToMySQL(cls.DB).query_db(query, recipe_data)
        return True
